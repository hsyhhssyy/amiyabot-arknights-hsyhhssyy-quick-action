#!/bin/sh

rm amiyabot-arknights-hsyhhssyy-quick-action-1.1.zip
zip -q -r amiyabot-arknights-hsyhhssyy-quick-action-1.1.zip *
